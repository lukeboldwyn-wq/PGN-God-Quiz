# PGN Master Study Challenge

Open `index.html` locally, or upload it to a GitHub repository and enable GitHub Pages under **Settings → Pages → Deploy from a branch → main / (root)**.


Note: The founder spelling `Marge Mclnerney Hawes` is reproduced exactly from the supplied quiz text. If the intended surname is `McInerney` (capital I rather than lowercase l), change it in `index.html` before publishing.
